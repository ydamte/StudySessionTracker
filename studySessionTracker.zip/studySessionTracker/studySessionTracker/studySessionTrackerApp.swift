//
//  studySessionTrackerApp.swift
//  studySessionTracker
//
//  Created by Yeabsera Damte on 11/1/24.
//

import SwiftUI

@main
struct studySessionTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
